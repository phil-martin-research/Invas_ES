This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported 
License(http://creativecommons.org/licenses/by-nc-sa/3.0/). 
The data presented in this file MAY NOT include all records shown on the datasheet. 
This occurs when we are unable to match a territory name to geographical coordinates in an authoritative manner.

Species distribution data from certain Compendia products has been made available for your use in KML and CSV formats. 
The KML format is a map presentation format which is compatible with a wide range of software, such as Google Earth. 
If you wish to obtain a copy of Google Earth go to http://earth.google.co.uk/ and follow the installation instructions. 
The CSV format allows you to quickly view the datasheet distribution data in spreadsheet package such as Microsoft Excel.

CABI is not responsible for the content of external sites.
